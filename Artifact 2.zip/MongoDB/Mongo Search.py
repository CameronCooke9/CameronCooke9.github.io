import json
import datetime
import pymongo
from bson import json_util
from pymongo import MongoClient

#establishing connection with mongo
connection = MongoClient('localhost', 27017)
db = connection['market']
collection = db['stocks']

#variable declairations
limit = 1
low = 1
high = 1
query = '!'
count = 1
result = '1'
sector = "!"
industry = "!"

#finding the highest averages
def highest_average(limit):
  for x in collection.find({}, {"Industry": "1"}).sort("50-Day Simple Moving Average", -1).limit(limit):
    print(x)
  return result

#finding the lowest averages
def lowest_average(limit):
  for x in collection.find({}, {"Industry": "1"}).sort("50-Day Simple Moving Average", 1).limit(limit):
    print(x)
  return result
  
#finding the 50 day average between 2 inputs
def average_between(low, high):
  print 'lowest average? \n'
  low = input()
  print 'highest average? \n'
  high = input()
  query ={'50-Day Simple Moving Average' : { '$gt' :  low, '$lt' : high}}
  for x in collection.find(query,{"industry":"1"}):
    print(x)
  count = result=collection.find(query).count
  print('count')
  print(count)
  return result
  function
  
#ticker function
def ticker(industry):
  print('Which industry are you interested in?')
  industry = input()
  for x in collection.find({"Industry" : "Medical Laboratories & Research"}, {"Ticker" : "1"}):
    print(x)
  return result
  
def agrigation(industry):
  print('Which sector are you interested in?')
  sector = input()
  
  collection.aggregate([{'$match':{'Sector':'Healthcare'}}, {'$group':{'Industry':"1",'Shares Outstanding': { '$sum': "$amount" }}}])
  return result
  
#main function
def main():
  selection = 0
  
  #menu
  while selection != 5:
    print ('What do you want to see?\n')
    print ('1 - highest 50-Day Simple Moving Average\n')
    print ('2 - lowest 50-Day Simple Moving Average\n')
    print ('3 - 50-Day Simple Moving Average between x and y\n')
    print ('4 - ticker symbols\n')
    print ('5 - aggregation pipeline\n')
    print('6 - quit')
    selection = input()
    
    #choosing which function to call
    if selection == 1:
      print('how many would you like to see?/n')
      limit = input()
      highest_average(limit)
    elif selection == 2:
      print('how many would you like to see?/n')
      limit = input()
      lowest_average(limit)
    elif selection == 3:
      average_between(low, high)
    elif selection == 4:
      ticker(industry)
    elif selection == 5:
      agrigation(sector)
    elif selection == 6:
      print('Exiting')
    else:
      print('Invalid input')
    
main()