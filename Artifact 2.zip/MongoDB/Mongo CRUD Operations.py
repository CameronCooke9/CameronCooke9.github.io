import json
import datetime
import pymongo
from bson import json_util
from pymongo import MongoClient

#establishing connection with mongo
connection = MongoClient('localhost', 27017)
db = connection['market']
collection = db['stocks']

#declairing variables
entry = {"name" : "test"}
search = {"name" : "test"}
old = {"name" : "test"}
new = {"name" : "testing"}
remove = {"name" : "testing"}
result = '1'


#create function
def create_document(entry):
  print 'Data to input? \n'
  entry = input()
  result=collection.insert(entry)
  print('Entry Created \n')
  return result

#read function
def read_document(search):
  print 'What are you looking for? \n' 
  search = input()
  for x in collection.find(search):
    print(x)
  print('Entry Found \n')
  return result  
  
#update function
def update_document(old, new):
  print 'What are you trying to update? \n'
  old = input()
  print 'What is it updating to? \n'
  new = input()
  result=collection.update(old, new)
  print('Entry Updated \n')
  return result

#delete function
def delete_document(remove):
  print 'What is beling deleted? \n'
  remove = input()
  collection.delete_one(remove)
  print('Entry Removed \n')
  return result
  
#main function
def main():
  selection = 0
  
  while selection != 5:
    print ('What do you want to do?\n')
    print ('1 - Create\n')
    print ('2 - Find\n')
    print ('3 - Update\n')
    print ('4 - Delete\n')
    print('5 - quit')
    selection = input()
    
    if selection == 1:
      create_document(entry)
    elif selection == 2:
      read_document(search)
    elif selection == 3:
      update_document(old, new)
    elif selection == 4:
      delete_document(remove)
    elif selection == 5:
      print('Exiting')
    else:
      print('Invalid input')
main()