import json
import datetime
import pymongo
from bson import json_util
from pymongo import MongoClient

#establishing connection with mongo
connection = MongoClient('localhost, 27017')
db = connection['city']
collection = db['inspections']

#create
create = {"id" : "Shipping-2020",
              "certificate_number" : 36915975,
              "business_name" : "The Shipping Co.",
              "date" : datetime.datetime.utcnow(),
              "result" : "Passed",
              "sector" : "Shipping",
              "address" : {
                "city" : "calais",
                "zip" : "04961",
                "street" : "main street",
                "number" : 340
          }
} 

#read
read = {"business_name" : "The Shipping Co."}

#update
query = {"business_name" : "The Shipping Co."}
newVal = {"$set": {"business_name" : "Four Cs Shipping Co."}}
    
#delete
delete = {"business_name" : 'Four Cs Shipping Co.'}

#create function
def create_document(entry):
  try:
    result=collection.insert_one(entry)
    print('Entry Created')
  except ValidationError as ve:
    abort(400, str(ve))
    return result

#read function
def read_document(search):
  try:   
    find=collection.find_one(search)
    print(find)
    print('Entry Found')
  except ValidationError as ve:
    abort(400, str(ve))
    return result  
  
#update function
def update_document(old, new):
  try:   
    result=collection.update_one(old, new)
    print('Entry Updated')
  except ValidationError as ve:
    abort(400, str(ve))
    return result

#delete function
def delete_document(remove):
  try:   
    result=collection.delete_one(remove)
    print('Entry Removed')
  except ValidationError as ve:
    abort(400, str(ve))
    return result
  
#main function
def main():
  create_document(create)
  read_document(read)
  update_document(query, newVal)
  delete_document(delete)
main()