import grovepi
import math
import json
import time,sys

humiditySensor = 8  # The humiditySensor goes on digital port 8.
lightSensor = 0 #the light sensor is in analog port A0
threshold = 50 #daytime when the sensor exceeds threshold resistance best guess for what may indicate daylight

redLED = 2 #the red light is in digital port 2
blueLED = 3 #the ble light is in digital port 3
greenLED = 4 #the green light is in digital port 4

# temp_humidity_sensor_type
# Grove Base Kit comes with the blue sensor.
blue = 0    # The Blue colored sensor.
white = 1   # The White colored sensor.
temp = 0
humidity = 0

if sys.platform == 'uwp':
    import winrt_smbus as smbus
    bus = smbus.SMBus(1)
else:
    import smbus
    import RPi.GPIO as GPIO
    rev = GPIO.RPI_REVISION
    if rev == 2 or rev == 3:
        bus = smbus.SMBus(1)
    else:
        bus = smbus.SMBus(0)

# this device has two I2C addresses
DISPLAY_RGB_ADDR = 0x62
DISPLAY_TEXT_ADDR = 0x3e

# set backlight to (R,G,B) (values from 0..255 for each)
def setRGB(r,g,b):
    bus.write_byte_data(DISPLAY_RGB_ADDR,0,0)
    bus.write_byte_data(DISPLAY_RGB_ADDR,1,0)
    bus.write_byte_data(DISPLAY_RGB_ADDR,0x08,0xaa)
    bus.write_byte_data(DISPLAY_RGB_ADDR,4,r)
    bus.write_byte_data(DISPLAY_RGB_ADDR,3,g)
    bus.write_byte_data(DISPLAY_RGB_ADDR,2,b)

# send command to display (no need for external use)
def textCommand(cmd):
    bus.write_byte_data(DISPLAY_TEXT_ADDR,0x80,cmd)

#Update the display without erasing the display
def setText_norefresh(text):
    textCommand(0x02) # return home
    time.sleep(.05)
    textCommand(0x08 | 0x04) # display on, no cursor
    textCommand(0x28) # 2 lines
    time.sleep(.05)
    count = 0
    row = 0
    while len(text) < 32: #clears the rest of the screen
        text += ' '
    for c in text:
        if c == '\n' or count == 16:
            count = 0
            row += 1
            if row == 2:
                break
            textCommand(0xc0)
            if c == '\n':
                continue
        count += 1
        bus.write_byte_data(DISPLAY_TEXT_ADDR,0x40,ord(c))

#creating the dict used to output the readings to a json file
outputData = {}
outputData['weather']  = []
outputData['weather'].append({
    'temperature' : temp,
    'humidity' : humidity
    })

grovepi.pinMode(lightSensor,"INPUT")
grovepi.pinMode(redLED,"OUTPUT")
grovepi.pinMode(blueLED,"OUTPUT")
grovepi.pinMode(greenLED,"OUTPUT")

grovepi.digitalWrite(greenLED,0)
grovepi.digitalWrite(blueLED,0)
grovepi.digitalWrite(redLED,0)


#creating a list to store the values to send to the json file
data = []

while True:
    try:
        #calculating the light data
        # Get sensor value
        light_sensor_value = grovepi.analogRead(lightSensor)

        # Calculate resistance of sensor in K
        resistance = (float)(1023 - light_sensor_value) * 10 / light_sensor_value
        
        #calculating the temperature data
        # The first parameter is the port, the second parameter is the type of sensor.
        [temp,humidity] = grovepi.dht(humiditySensor,blue)
        
        # math formula to change the Celsius reading to F
        temp = ((temp * 9) / 5.0 ) + 32

        if resistance < threshold:
            #daytime
            
            if temp > 60 and temp < 85 and humidity < 80:
                grovepi.digitalWrite(greenLED,1)
                grovepi.digitalWrite(blueLED,0)
                grovepi.digitalWrite(redLED,0)
            
            elif temp >= 85 and temp < 95 and humidity < 80:
                grovepi.digitalWrite(blueLED,1)
                grovepi.digitalWrite(greenLED,0)
                grovepi.digitalWrite(redLED,0)
            
            elif temp >= 95: 
                grovepi.digitalWrite(redLED,1)
                grovepi.digitalWrite(blueLED,0)
                grovepi.digitalWrite(greenLED,0)
            
            elif humidity >= 80: 
                grovepi.digitalWrite(blueLED,1)
                grovepi.digitalWrite(greenLED,1)
                grovepi.digitalWrite(redLED,0)
            
            else:
                grovepi.digitalWrite(greenLED,0)
                grovepi.digitalWrite(blueLED,0)
                grovepi.digitalWrite(redLED,0)
            
        else:
            # nighttime
            grovepi.digitalWrite(greenLED,0)
            grovepi.digitalWrite(blueLED,0)
            grovepi.digitalWrite(redLED,0)
            

        print("light sensor value = %d resistance = %.2f" %(light_sensor_value,  resistance))
        
        
        if math.isnan(temp) == False and math.isnan(humidity) == False:
            #this is the statment sending the data to the lcd screen
            setText_norefresh("temp = %.02f F  humidity =%.02f%%"%(temp, humidity))
            #prints the data to the shell
            print("temp = %.02f F humidity =%.02f%%"%(temp, humidity))
            
            #adds each new reading to the list
            data.append([temp, humidity])
            
            #outputting the data list to the data json file
            with open ('FinalProjectData.json', 'w') as outfile:
                json.dump(data, outfile,)
                
            #stops the loop so it takes a reading every 30 minutes
            time.sleep(1800)

            
    except IOError:
        print ("Error")
        
