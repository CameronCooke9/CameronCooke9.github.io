#include <Python.h>
#include <iostream>
#include <Windows.h>
#include <cmath>
#include <string>

using namespace std;

int input, userNum;

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("doublevalue",5);
Return:
	25 is returned to the C++
*/
int callIntFunc(string proc, int param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"Python");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(i)", param);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;

	return _PyLong_AsInt(presult);
}

//get the number to be used in the multiplicaton or double function
void GetNum() {
	cout << "What number would you like to work with?" << endl;

	cin >> userNum;
}

//display the menu and get user selectioon
void Menu() {

	//menu
	cout << "1: Display a Multiplication Table" << endl;
	cout << "2: Double a Value" << endl;
	cout << "3: Exit" << endl;
	cout << "Enter your selection as a number 1, 2, or 3." << endl;

	cin >> input;

	//invalid input loop
	if (input != 1 && input != 2 && input != 3) {
		cout << "Invalid Input" << endl << endl;
		Menu();
	}
	//if user wants to exit the program
	if (input == 3) {
		exit(1);
	}
}

//function for displaying a multiplication table
void MultiTable() {
	cout << callIntFunc("MultiplicationTable", userNum) << endl;
}

//funtion for doubleing an input
void DoubleNum() {
	cout << callIntFunc("DoubleValue", userNum) << endl;
}

void main(){

	//allows you to use the program multiple times without closing
	while (input != 3) {
		Menu();
		GetNum();

		if (input == 1) {
			MultiTable();
		}
		if (input == 2) {
			DoubleNum();	
		}
	}
}