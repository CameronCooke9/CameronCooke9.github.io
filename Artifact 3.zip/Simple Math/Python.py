import re
import string


def printsomething():
    print("Hello from python!")

def PrintMe(v):
    print("You sent me: " + v)
    return 100;

#function to double the passed value
def DoubleValue(v):
    return v * 2

#function to display the multiplication table
def MultiplicationTable(multiple):
    i = 1
    
    while i <= 10:
        print(multiple, " X ", i, " = ", multiple * i)
        i = i + 1
    return 1

