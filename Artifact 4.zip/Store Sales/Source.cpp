//Include statements
#include <Python.h>
#include <iostream>
#include <Windows.h>
#include <cmath>
#include <string>
#include <fstream>
#include <vector>

using namespace std;

//intial global variables
int input, i, x, num;
string userItem, item;

/*
Description:
	To call this function, simply pass the function name in Python that you wish to call.
Example:
	callProcedure("printsomething");
Output:
	Python will print on the screen: Hello from python!
Return:
	None
*/
void CallProcedure(string pName)
{
	char* procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyObject* my_module = PyImport_ImportModule("Python");
	PyErr_Print();
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("PrintMe","Test");
Output:
	Python will print on the screen:
		You sent me: Test
Return:
	100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	char* paramval = new char[param.length() + 1];
	std::strcpy(paramval, param.c_str());


	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"Python");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(z)", paramval);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;
	delete[] paramval;


	return _PyLong_AsInt(presult);
}

//function to get the specific item to see how many times it was sold
void GetItem() {
	cout << "what item are you looking for?" << endl;

	cin >> userItem;
	cout << endl;
}

//display the menu and get user selection
void Menu() {

	//menu
	cout << "1: Todays Sales" << endl;
	cout << "2: Item Quantity Sold" << endl;
	cout << "3: Sales Histogram" << endl;
	cout << "4: Exit" << endl;
	cout << "Enter your selection as a number 1, 2, or 3." << endl;

	cin >> input;
	cout << endl;

	//invalid input loop
	if (input != 1 && input != 2 && input != 3 && input != 4) {
		cout << "Invalid Input" << endl << endl;
		Menu();
	}

	//if user wants to exit the program
	if (input == 4) {
		exit(1);
	}
}

// reading a .dat file made by the python code and outputing the data
void ReadFile() {

	cout << "Todays sales:" << endl;
	
	ifstream inFile("frequency.dat");

	//if the file is found
	if (inFile.is_open()) {
		for (i = 0; i < 20; ++i) {
			//basically the same as a cin but for files
			inFile >> item >> num;
			cout << item << " ";
			x = 0;
			while( x < num) {
				cout << 'X';
				++x;
			}
			cout << endl;
		}
		cout << endl;
	}
	//file not found
	else {
		cout << "ERROR: File doesnt open/exist";
	}
	//close the file once the input is received
	inFile.close();
}

//main function
int main()
{

	//allows you to use the program multiple times without closing
	while (input != 4) {
		//initial display of the menu
		Menu();

		//if statements based on user selection
		if (input == 1) {
			CallProcedure("TodaySales");
			cout << endl;
		}
		else if (input == 2) {
			GetItem();
			cout << "You sold " << userItem << " " << callIntFunc("ItemSales", userItem) << " today." << endl << endl;
		}
		else if (input == 3) {
			CallProcedure("WriteFile");
			ReadFile();
		}
		else {
			cout << "Error";
			exit(1);
		}
	}
	
	return 0;
}