import re
import string
from collections import Counter

rawSales = []
strippedSales = []
instances = []

#reading from the txt file and converting it to a list
f = open("Sales.txt", "r")

for x in f:
    rawSales.append(x)

#closing the file
f.close()

# stripping the new line character form the original list
for element in rawSales:
    strippedSales.append(element.strip())

#couting how many times each item occures in the list
instances = Counter(strippedSales)

#print(strippedSales)

def printsomething():

    print("Hello from python!")

def PrintMe(v):
    print("You sent me: " + v)
    return 100;

def SquareValue(v):

    return v * v

#printing the number of sales for each items
def TodaySales():   

    print("Todays Sales:")

    for x in instances:
        print (strippedSales.count(x), x)

#returns the number of instances of the specific item in the sales list
def ItemSales(item):

    return strippedSales.count(item)

#displaying a histogram using * for todays sales
def WriteFile():

    #creating a file to store the frequency data 
    outFile = open("frequency.dat", "w")

    #iterate through the list
    for x in instances:
        outFile.write("{} {} \n".format(x, strippedSales.count(x)))

    #close the file
    outFile.close()
